Eclipse Armor 中文（简体）翻译 v1.0

说明：
本压缩包仅包含 Eclipse Armor 的简体中文语言文件，用于替换或补充模组语言。此压缩包不包含模组本体（.jar）或任何资源/模型，仅提供 `zh_cn.json`。

文件结构（压缩包内）：
assets/eclipsearchor/lang/zh_cn.json

安装说明：
1. 请先确保已安装原始模组 Eclipse Armor（来自 CurseForge 等渠道）。
2. 将压缩包内的 `assets` 文件夹合并到你的模组目录或资源包目录中：
   - 若作为模组语言替换：将 `assets/eclipsearchor/lang/zh_cn.json` 放入你的模组安装目录：
     `<minecraft instance>/mods/eclipsearmor/assets/eclipsearchor/lang/zh_cn.json`（路径可能因模组管理器而异，请参照你的环境）。
   - 若作为资源包使用：将压缩包放入资源包文件夹并在游戏中启用，或手动解压并把 `assets` 文件夹合并到现有资源包中。
3. 启动游戏并在语言设置中选择“简体中文”。

版权与声明：
Eclipse Armor 的代码与资源归原作者所有。翻译由 [你的昵称] 制作，仅为社区提供汉化文本。分发或使用本汉化时，请保留以下原始链接与署名：
原模组页面（CurseForge）：https://www.curseforge.com/minecraft/mc-mods/eclipse-armor

许可：
- 本汉化仅包含语言文件；允许非商业分享。不得删除原作者的署名或以本汉化替换原作者声明。
- 若您想与模组本体或资源一并分发，请先取得原作者书面许可。

反馈与联系方式：
在 MineBBS 帖子中回复或联系发布者（用户名）。

感谢：
感谢 Eclipse Armor 原作者制作优秀模组，感谢社区的支持与反馈。